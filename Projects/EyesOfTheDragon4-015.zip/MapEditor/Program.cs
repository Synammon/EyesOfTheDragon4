﻿
using var game = new MapEditor.Editor();
game.Run();
