﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SharedProject.Mobs
{
    public class MoveFactory
    {
        public static MoveFactory instance;
        private Dictionary<string, Move> Moves { get; set; } = new();

        private MoveFactory() 
        {
            IEnumerable<Move> exporters = typeof(Move)
                .Assembly.GetTypes()
                .Where(t => t.IsSubclassOf(typeof(Move)) && !t.IsAbstract)
                .Select(t => (Move)Activator.CreateInstance(t));

            foreach (Move move in exporters)
            {
                Type type = move.GetType();
                Moves.Add(type.Name, move);
            }
        }

        public static MoveFactory getInstance() 
        { 
            if (instance == null)
            {
                instance = new MoveFactory();
            }

            return instance; 
        }

        public void GetMove(string name)
        {

        }
    }
}
