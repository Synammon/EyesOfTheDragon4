﻿
using var game = new EyesOfTheDragon.Desktop();
game.Run();
